﻿using System.Windows;
using System.Windows.Input;


namespace LittleDragon.ViewModel
{
    public class MainViewModel
    {

        public ICommand StartCommand { get; }

        public MainViewModel()
        {
            StartCommand = new RelayCommand(OnStart);
        }

        private void OnStart()
        {
            // Логика, которая должна выполняться при нажатии кнопки
            SeriesSelectionWindow seriesSelectionWindow = new SeriesSelectionWindow();
            seriesSelectionWindow.Show();
            Application.Current.MainWindow.Close();
        }
    }
}
