﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LittleDragon
{
    /// <summary>
    /// Логика взаимодействия для SecondSeriesWindow.xaml
    /// </summary>
    public partial class SecondSeriesWindow : Window
    {
        public SecondSeriesWindow()
        {
            InitializeComponent();
            
            
        }
        private void Option1_Click(object sender, RoutedEventArgs e)
        {
           
            // Логика завершения второй серии
            EndGame();
        }

        private void Option2_Click(object sender, RoutedEventArgs e)
        {
           
            EndGame();
        }

        private void EndGame()
        {
            MessageBox.Show("Поздравляем, вы завершили историю!", "Завершение игры", MessageBoxButton.OK);
            MainWindow mainMenu = new MainWindow();
            mainMenu.Show();
            this.Close();
        }
    }
}
