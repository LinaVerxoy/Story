﻿using LittleDragon.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows;
using System.Windows.Controls;


namespace LittleDragon.ViewModel
{
    public class FirstSeriesViewModel : INotifyPropertyChanged
    {
        private int _currentSceneIndex;
        private Scene _currentScene;
        private List<Scene> _scenes;

        public event PropertyChangedEventHandler? PropertyChanged;

        public void OnPropertyChanged()
        {

        }
        public FirstSeriesViewModel()
        {
            LoadCurrentScene();
            SelectOptionCommand = new RelayCommand<int>(SelectOption);
        }
        public Scene CurrentScene
        {
            get => _currentScene;
            set
            {
                _currentScene = value;
                OnPropertyChanged();
            }
        }
        public ICommand SelectOptionCommand { get; }

        private void InitializeScenes()
        {
            _scenes = new List<Scene>
        {
            new Scene
            {
                Text = "В одном маленьком городке, где утро всегда начиналось с пения птиц, жил мальчик по имени Петя. Однажды, проснувшись рано, он решил, что пора выбраться на улицу и насладиться свежим воздухом. Солнечные лучи пробивались сквозь зелёные деревья, а вокруг было так спокойно. Вдруг он услышал тихое мяуканье, доносящееся из кустов. ",
                ImagePath = "Images/Cat1.jpg",
                Options = new List<Option>
                {
                    new Option { Text = "Пойти на звук", NextSceneIndex = 1 },
                    new Option { Text = "Засомневаться и пойти дальше", NextSceneIndex = 2 }
                }
            },
            new Scene
            {
                Text = "Он подошёл ближе и увидел маленького котёнка, который запутался в ветках. Его зелёные глаза были полны страха, но при этом в них читалось надежда. Петя сразу же понял, что нельзя оставлять малыша в беде. Он осторожно освободил котёнка и прижал его к себе..",
                ImagePath = "Images/Cat2.jpg",
                Options = new List<Option>
                {
                    new Option { Text = "Оставить котёнка себе", NextSceneIndex = 3 },
                    new Option { Text = "Временно приютить", NextSceneIndex = 4 }
                }
            },
            new Scene
            {
                 Text = "Пройдя пару шагов, Петя всё же решил проверить в чём дело. Уж больно он любил братьев наших меньших и, наоборот, считал своим долгом помогать животным. Развернувшись, Петя всё же пошёл к источнику звука",
            ImagePath = "Images/Pic1.jpg",
            Options = new List<Option>
            {
                new Option { Text = "Проверить кусты", NextSceneIndex = 1 },
                new Option { Text = "Подождать", NextSceneIndex = 5 }
            }
            },
            new Scene
            {
                 Text = "Мальчик рад своему новому другу!.",
            ImagePath = "Images/Cat3.jpg",
            Options = new List<Option>
            {
                new Option { Text = "Пойти домой вместе с котиком", NextSceneIndex = 6 },
                new Option { Text = "Прогуляться ещё", NextSceneIndex = 7 }
            }
            },
            new Scene
            {
                 Text = "'Бедный! Я тебя не оставлю здесь. Но смогу приютить тебя на какое-то время, а там уже видно будет'- ласково сказал мальчик котёнку, словно тот понимает слова Пети.",
            ImagePath = "Images/Cat1.jpg",
            Options = new List<Option>
            {
                new Option { Text = "Отправиться домой", NextSceneIndex = 8 },
                new Option { Text = "Прогуляться до речки", NextSceneIndex = 9 }
            }
            },
            new Scene
            {

            Text = "Из кустов спустя некоторое время выбежал маленький котёнок. Он был так напуган, что дрожь проходила по всему его маленькому тельцу. Но Петя всё же решил забрать котёнка и помыть. Они отправились к речке",
            ImagePath = "Images/Pic2.jpg",
            Options = null
            },
            new Scene
            {
                 Text = "Теперь с мальчиком живёт пушистый комочек (или мальчик у него).",
            ImagePath = "Images/Cat4.jpg",
            Options = null
            },
            new Scene
            {
             Text = "Петя отмыл бедолагу, а затем ещё долго сидели возле речки, любуясь на закат.",
             ImagePath = "Images/Pic2.jpg",
             Options = null
            },
            new Scene
            {
             Text = "Взяв котёнка на руки по-удобнее, Петя отправился домой. К сожалению, родители не имели возможности содержать питомца, несмотря на их безграничную любовь к животным. Пушистик временно поживёт у Пети дома, но вскоре обретёт любящую семью.",
             ImagePath = "Images/Cat1.jpg",
             Options = null
            },
            new Scene
            {
             Text = "Вы забыли о драконе и продолжили свою жизнь.",
            ImagePath = "Images/Cat3.jpg",
            Options = null
            },


        };
        }
        
        public int currentSceneIndex
        {
            get
            {
                return _currentSceneIndex;
            }
            set
            {
                _currentSceneIndex = value;
            }
        }
        private void LoadCurrentScene()
        {
            if (currentSceneIndex < scenes.Count)
            {
                var scene = scenes[currentSceneIndex];
                StoryTextBlock.Text = scene.Text;
                Image.Source = new BitmapImage(new Uri(@"/" + scene.ImagePath, UriKind.Relative));
                ButtonPanel.Children.Clear(); // Очищаем предыдущие кнопки

                if (scene.Options != null)
                {
                    foreach (var option in scene.Options)
                    {
                        var button = new Button
                        {
                            Content = option.Text,
                            Margin = new Thickness(5),
                            Height = 50,
                            Width = 171
                        };
                        button.Click += (s, e) =>
                        {
                            currentSceneIndex = option.NextSceneIndex;
                            LoadCurrentScene();
                        };
                        ButtonPanel.Children.Add(button);
                    }
                }
                else
                {
                    EndSeries();
                }
            }
        }
        private void EndSeries()
        {
            SeriesSelectionWindow.IsFirstSeriesCompleted = true;
            MessageBox.Show("Первая серия завершена. Выберите дальнейшее действие.", "Завершение серии", MessageBoxButton.OK);
            SeriesSelectionWindow seriesSelectionWindow = new SeriesSelectionWindow();
            seriesSelectionWindow.Show();
            //this.Close();
        }
    }

}
